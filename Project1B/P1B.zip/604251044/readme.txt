Alfred Lucero
ID:604251044

I used basic HTTP GET protocols to request for user input and used the mysql
functions in PHP in order to access the database and send queries. The 
violation of constraints involve simple INSERT statements that break the
primary and foreign key references. We used InnoDB in order to use FOREIGN
KEYS.
