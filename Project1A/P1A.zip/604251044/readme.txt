I worked alone on this project, and I used tutorials to help me with the regular
expressions and php GET method. It can successfully handle the suggested test cases,
and it models the example calculator given to us for project 1A.